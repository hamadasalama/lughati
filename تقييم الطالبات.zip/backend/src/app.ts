import express from 'express';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { env } from './config';
import { q } from './database/pool';
import { notFound, errorHandler } from './middleware/errors';
import authRoutes from './routes/auth';
import usersRoutes from './routes/users';
import studentsRoutes from './routes/students';
import evaluationsRoutes from './routes/evaluations';
import worksheetsRoutes from './routes/worksheets';
import testsRoutes from './routes/tests';
import plansRoutes from './routes/plans';
import skillsRoutes from './routes/skills';
import messagesRoutes from './routes/messages';
import starRoutes from './routes/star';
import achievementsRoutes from './routes/achievements';
import filesRoutes from './routes/files';
import reportsRoutes from './routes/reports';
import settingsRoutes from './routes/settings';
import auditRoutes from './routes/audit';

export function createApp(opts: { staticDir?: string } = {}) {
  const app = express();
  app.use(cors({ origin: env.corsOrigin, credentials: true }));
  app.use(express.json({ limit: '1mb' }));
  app.use(cookieParser());

  // فحص صحة فعلي: يلمس قاعدة البيانات حقيقةً
  app.get('/api/health', async (_req, res) => {
    const { rows } = await q('SELECT now() AS now');
    res.json({ status: 'ok', db: 'ok', now: rows[0].now });
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/users', usersRoutes);
  app.use('/api/students', studentsRoutes);
  app.use('/api/evaluations', evaluationsRoutes);
  app.use('/api/worksheets', worksheetsRoutes);
  app.use('/api/tests', testsRoutes);
  app.use('/api/plans', plansRoutes);
  app.use('/api/skills', skillsRoutes);
  app.use('/api/messages', messagesRoutes);
  app.use('/api/star', starRoutes);
  app.use('/api/achievements', achievementsRoutes);
  app.use('/api/files', filesRoutes);
  app.use('/api/reports', reportsRoutes);
  app.use('/api/settings', settingsRoutes);
  app.use('/api/audit', auditRoutes);

  // في الإنتاج: تقديم واجهة React المبنية من نفس الخادم
  if (opts.staticDir && fs.existsSync(opts.staticDir)) {
    app.use(express.static(opts.staticDir));
    app.use((req, res, next) => {
      if (req.method === 'GET' && !req.path.startsWith('/api'))
        return res.sendFile(path.join(opts.staticDir!, 'index.html'));
      next();
    });
  }

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
