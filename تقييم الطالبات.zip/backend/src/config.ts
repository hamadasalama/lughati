// الإعدادات تأتي من متغيرات البيئة فقط — لا سرّ في كود الواجهة مطلقاً
import dotenv from 'dotenv';
import path from 'path';

// .env في جذر المشروع بينما الأوامر تعمل من مجلد backend — لذلك المسار صريح،
// مع محاولة ثانية من مجلد التشغيل الحالي (dotenv لا يستبدل متغيراً موجوداً مسبقاً)
dotenv.config({ path: path.resolve(__dirname, '../../.env') });
dotenv.config();

const req = (k: string, d?: string): string => {
  const v = process.env[k] ?? d;
  if (v === undefined) throw new Error('متغير بيئة مفقود: ' + k + ' (تأكدي من وجود ملف .env في جذر المشروع)');
  return v;
};

export const env = {
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: +req('PORT', '4000'),
  databaseUrl: req('DATABASE_URL'),
  jwtSecret: req('JWT_SECRET'),
  corsOrigin: req('CORS_ORIGIN', 'http://localhost:5173'),
  uploadDir: req('UPLOAD_DIR', 'uploads'),
  maxUploadMb: +req('MAX_UPLOAD_MB', '6'),
  migrationsDir: req('MIGRATIONS_DIR', path.resolve(__dirname, '../../database/migrations')),
  seedsDir: req('SEEDS_DIR', path.resolve(__dirname, '../../database/seeds')),
  uploadDirAbs: path.resolve(__dirname, '..', req('UPLOAD_DIR', 'uploads'))
};
