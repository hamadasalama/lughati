import path from 'path';
import fs from 'fs';
import { wrap } from '../middleware/errors';
import * as svc from '../services/files';
import { audit } from '../services/audit';
import { env } from '../config';
import { HttpError } from '../middleware/errors';

export const download = wrap(async (req, res) => {
  const f = await svc.getForDownload(+req.params.id);
  // 404 بدل 403 عند عدم الملكية: لا نكشف حتى وجود الملف لمن يحاول تخمين الروابط
  if (!f || !svc.accessible(req.user!, f)) throw new HttpError(404, 'الملف غير موجود');
  const abs = path.join(env.uploadDirAbs, f.stored_name);
  if (!fs.existsSync(abs)) throw new HttpError(404, 'الملف غير موجود');
  await audit(req, 'file.download', 'file', f.id, { kind: f.kind });
  res.download(abs, f.original_name);
});
