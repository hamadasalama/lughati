import { wrap } from '../middleware/errors';
import * as svc from '../services/settings';
import { HttpError } from '../middleware/errors';

export const get = wrap(async (_req, res) => res.json(await svc.getAll()));
export const put = wrap(async (req, res) => res.json(await svc.put(req.body)));
export const logo = wrap(async (req, res) => {
  const f = (req as any).file;
  if (!f) throw new HttpError(400, 'اختاري ملف الشعار');
  res.json(await svc.setLogo(f, (req.body.which === 'moe' ? 'moe' : 'school'), req.user!.id));
});
