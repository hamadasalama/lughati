import { wrap } from '../middleware/errors';
import * as svc from '../services/auth';
import { setAuthCookie, clearAuthCookie } from '../middleware/auth';
import { audit } from '../services/audit';

export const login = wrap(async (req, res) => {
  try {
    const r = await svc.login(req.body.username, req.body.password);
    setAuthCookie(res, r.token);
    await audit(req, 'login', 'user', r.user.id, { username: r.user.username });
    res.json({ user: r.user });
  } catch (e) {
    await audit(req, 'login_fail', 'user', null, { username: String(req.body?.username ?? '') });
    throw e;
  }
});
export const logout = wrap(async (req, res) => { clearAuthCookie(res); res.json({ ok: true }); });
export const me = wrap(async (req, res) => res.json({ user: req.user }));
export const changePassword = wrap(async (req, res) => {
  await svc.changePassword(req.user!.id, req.body.new, req.body.current, true);
  await audit(req, 'password.change', 'user', req.user!.id, {});
  res.json({ ok: true }); // كل الجلسات الأخرى بطلت تلقائياً (token_version)
});
