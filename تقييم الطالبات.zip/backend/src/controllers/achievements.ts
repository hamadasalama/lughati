import { wrap } from '../middleware/errors';
import * as svc from '../services/achievements';
import { audit } from '../services/audit';

export const list = wrap(async (req, res) => res.json(await svc.list(req.user!)));
export const create = wrap(async (req, res) => {
  const row = await svc.create(req.user!, req.body, (req as any).files ?? []);
  await audit(req, 'achievement.create', 'achievement', row.id, { title: row.title });
  res.status(201).json(row);
});
export const update = wrap(async (req, res) => res.json(await svc.update(+req.params.id, req.body)));
export const remove = wrap(async (req, res) => { await svc.remove(+req.params.id); res.status(204).end(); });
