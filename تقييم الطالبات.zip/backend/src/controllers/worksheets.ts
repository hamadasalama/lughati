import { wrap } from '../middleware/errors';
import * as svc from '../services/worksheets';
import { audit } from '../services/audit';

export const list = wrap(async (req, res) => res.json(await svc.list(req.user!, req.query as any)));
export const create = wrap(async (req, res) => {
  const row = await svc.create(req.user!, req.body, (req as any).file);
  await audit(req, 'worksheet.create', 'worksheet', row.id, { title: row.title, grade: row.grade, section: row.section });
  res.status(201).json(row);
});
export const setStatus = wrap(async (req, res) => res.json(await svc.setStatus(+req.params.id, Number(req.body.student_id), !!req.body.done)));
export const remove = wrap(async (req, res) => { await svc.remove(+req.params.id); res.status(204).end(); });
