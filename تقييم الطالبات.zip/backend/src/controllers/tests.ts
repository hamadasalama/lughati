import { wrap } from '../middleware/errors';
import * as svc from '../services/tests';
import { audit } from '../services/audit';

export const list = wrap(async (req, res) => res.json(await svc.list(req.user!, req.query as any)));
export const create = wrap(async (req, res) => {
  const row = await svc.create(req.user!, req.body);
  await audit(req, 'test.create', 'test', row.id, { title: row.title, kind: row.kind });
  res.status(201).json(row);
});
export const saveResults = wrap(async (req, res) => {
  const r = await svc.saveResults(req.user!, +req.params.id, req.body.rows);
  await audit(req, 'test.results', 'test', +req.params.id, { saved: r.saved });
  res.json(r);
});
export const remove = wrap(async (req, res) => { await svc.remove(+req.params.id); res.status(204).end(); });
