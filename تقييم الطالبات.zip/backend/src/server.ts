import path from 'path';
import { createApp } from './app';
import { env } from './config';
import { pool } from './database/pool';

const app = createApp({ staticDir: path.resolve(__dirname, '../../frontend/dist') });

app.listen(env.port, async () => {
  console.log('✔ منصة لغتي تعمل على المنفذ ' + env.port);
  try { await pool.query('SELECT 1'); console.log('✔ اتصال قاعدة البيانات سليم'); }
  catch (e) { console.error('✖ تعذر الاتصال بقاعدة البيانات — راجعي DATABASE_URL', e); }
});
