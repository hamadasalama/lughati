import { Request, Response, NextFunction } from 'express';

export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
type H = (req: Request, res: Response, next: NextFunction) => unknown;
export const wrap = (fn: H) => (req: Request, res: Response, next: NextFunction) =>
  Promise.resolve(fn(req, res, next)).catch(next);

export function notFound(_req: Request, res: Response) { res.status(404).json({ error: 'المسار غير موجود' }); }
export function errorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  let status = err instanceof HttpError ? err.status : 500;
  // ملف مرفوع أكبر من الحد المسموح: رسالة واضحة بحالة 400 بدل 500
  if (err?.code === 'LIMIT_FILE_SIZE') { status = 400; err.message = 'حجم الملف أكبر من الحد المسموح'; }
  if (status >= 500) console.error(err);
  res.status(status).json({ error: err.message || 'حدث خطأ في الخادم' });
}
