import crypto from 'crypto';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { env } from '../config';

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => { fs.mkdirSync(env.uploadDirAbs, { recursive: true }); cb(null, env.uploadDirAbs); },
  filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname || ''))
});
export const upload = multer({
  storage,
  limits: { fileSize: env.maxUploadMb * 1024 * 1024, files: 10 }
});
