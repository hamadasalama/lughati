import fs from 'fs';
import path from 'path';
import { env } from '../config';
import { pool } from '../database/pool';

export async function runMigrations(dir = env.migrationsDir) {
  await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations(name varchar(120) PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  for (const f of files) {
    const done = await pool.query('SELECT 1 FROM schema_migrations WHERE name = $1', [f]);
    if (done.rowCount) continue;
    await pool.query(fs.readFileSync(path.join(dir, f), 'utf8'));
    await pool.query('INSERT INTO schema_migrations(name) VALUES ($1)', [f]);
    console.log('✔ migration:', f);
  }
}

if (require.main === module) {
  runMigrations()
    .then(() => pool.end())
    .then(() => process.exit(0))
    .catch(e => { console.error('✖ فشل الترحيل:', e.message); process.exit(1); });
}
