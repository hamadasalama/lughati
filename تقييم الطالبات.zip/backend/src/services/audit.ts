import { Request } from 'express';
import { q } from '../database/pool';

export async function audit(req: Request, action: string, entity: string, entityId?: string | number | null, details?: unknown) {
  const u = req.user;
  await q(
    'INSERT INTO audit_logs(user_id, username, role, action, entity, entity_id, details, ip) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
    [u?.id ?? null, u?.username ?? null, u?.role ?? null, action, entity,
     entityId != null ? String(entityId) : null, details ?? null, (req as any).ip ?? null]);
}

export async function list(opts: { limit?: number; user_id?: number }) {
  const limit = Math.min(Math.max(opts.limit ?? 100, 1), 500);
  const { rows } = await q(
    'SELECT * FROM audit_logs WHERE ($1::int IS NULL OR user_id = $1) ORDER BY at DESC LIMIT $2',
    [opts.user_id ?? null, limit]);
  return rows;
}
