import { q } from '../database/pool';
import { HttpError } from '../middleware/errors';
import { UpFile } from '../middleware/upload';
import * as filesSvc from './files';

export const DEFAULTS: Record<string, any> = {
  schoolName: 'اسم المدرسة',
  eduAdmin: 'الإدارة العامة للتعليم',
  principal: 'أ. بدور الجارد',
  teacher: 'أ. مها الحمادي',
  grades: ['الرابع', 'الخامس', 'السادس'],
  classes: ['أ', 'ب'],
  scale: { max: 5, labels: { '5': 'ممتاز', '4': 'جيد جدًا', '3': 'جيد', '2': 'يحتاج إلى تحسين', '1': 'يحتاج إلى متابعة' } },
  alerts: { lowStreak: 3, lowThreshold: 2, absenceDays: 3, noEvalDays: 14 },
  info: { about: '', goals: '', bio: '' },
  logoSchool: null,
  logoMoe: null
};

export async function getAll() {
  const { rows } = await q<{ key: string; value: any }>('SELECT key, value FROM settings');
  const out: Record<string, any> = { ...DEFAULTS };
  for (const r of rows) out[r.key] = r.value;
  return out;
}

export async function put(patch: Record<string, any>) {
  for (const [k, v] of Object.entries(patch)) {
    if (!(k in DEFAULTS)) throw new HttpError(400, 'مفتاح إعدادات غير معروف: ' + k);
    await q(
      'INSERT INTO settings(key, value) VALUES ($1, $2::jsonb) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()',
      [k, JSON.stringify(v ?? null)]);
  }
  return getAll();
}

export async function setLogo(file: UpFile, which: 'school' | 'moe', userId: number) {
  const key = which === 'moe' ? 'logoMoe' : 'logoSchool';
  // الشعار القديم يُحذف فعلياً من القرص عند الاستبدال
  const cur = await q('SELECT value FROM settings WHERE key = $1', [key]);
  const oldId = cur.rows[0]?.value?.file_id;
  if (oldId) {
    const old = await q("DELETE FROM files WHERE id = $1 AND kind = 'logo' RETURNING stored_name", [oldId]);
    if (old.rows[0]) filesSvc.unlinkSafe(old.rows[0].stored_name);
  }
  const reg = await filesSvc.register({
    stored_name: file.filename, original_name: file.originalname, mime: file.mimetype, size: file.size,
    kind: 'logo', student_id: null, worksheet_id: null, achievement_id: null, uploaded_by: userId
  });
  return put({ [key]: { file_id: reg.id } });
}
