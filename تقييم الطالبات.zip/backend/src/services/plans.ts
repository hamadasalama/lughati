import { q } from '../database/pool';
import { HttpError } from '../middleware/errors';
import { AuthUser, assertStudentAccess } from '../middleware/auth';

export async function list(user: AuthUser, studentId?: number) {
  const sid = user.role === 'student' ? user.studentId! : (studentId ?? null);
  assertStudentAccess(user, sid ?? -1);
  const { rows } = await q(
    `SELECT p.*, COALESCE(json_agg(json_build_object('id', f.id, 'follow_date', f.follow_date, 'note', f.note) ORDER BY f.follow_date)
             FILTER (WHERE f.id IS NOT NULL), '[]') AS followups
     FROM plans p LEFT JOIN plan_followups f ON f.plan_id = p.id
     WHERE ($1::int IS NULL OR p.student_id = $1)
     GROUP BY p.id ORDER BY p.status, p.to_date DESC NULLS LAST`, [sid]);
  return rows;
}

export async function create(user: AuthUser, b: any) {
  const sid = Number(b.student_id);
  if (!sid) throw new HttpError(400, 'حددي الطالبة');
  if (!b.title || !String(b.title).trim()) throw new HttpError(400, 'عنوان الخطة مطلوب');
  const { rows } = await q(
    `INSERT INTO plans(student_id, title, goal, actions, from_date, to_date, created_by)
     VALUES ($1,$2,$3,$4,$5::date,$6::date,$7) RETURNING *`,
    [sid, String(b.title).trim(), b.goal || null, b.actions || null, b.from_date || null, b.to_date || null, user.id]);
  return rows[0];
}

export async function update(id: number, b: any) {
  const { rows } = await q(
    `UPDATE plans SET title = COALESCE($2, title), goal = COALESCE($3, goal), actions = COALESCE($4, actions),
       from_date = COALESCE($5::date, from_date), to_date = COALESCE($6::date, to_date), status = COALESCE($7, status)
     WHERE id = $1 RETURNING *`,
    [id, b.title ?? null, b.goal ?? null, b.actions ?? null, b.from_date ?? null, b.to_date ?? null, b.status ?? null]);
  if (!rows[0]) throw new HttpError(404, 'الخطة غير موجودة');
  return rows[0];
}

export async function addFollowup(user: AuthUser, planId: number, b: any) {
  if (!b.note || !String(b.note).trim()) throw new HttpError(400, 'ملاحظة المتابعة مطلوبة');
  const { rows } = await q(
    'INSERT INTO plan_followups(plan_id, follow_date, note) VALUES ($1, COALESCE($2::date, CURRENT_DATE), $3) RETURNING *',
    [planId, b.follow_date || null, String(b.note).trim()]);
  return rows[0];
}

export async function remove(id: number) {
  const { rows } = await q('DELETE FROM plans WHERE id = $1 RETURNING id', [id]);
  if (!rows[0]) throw new HttpError(404, 'الخطة غير موجودة');
  return rows[0];
}
