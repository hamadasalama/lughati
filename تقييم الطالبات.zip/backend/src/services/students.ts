import { q } from '../database/pool';
import { HttpError } from '../middleware/errors';
import { AuthUser } from '../middleware/auth';

export async function list(f: { grade?: string; section?: string; q?: string }) {
  const { rows } = await q(
    `SELECT * FROM students
     WHERE active AND ($1::text IS NULL OR grade = $1) AND ($2::text IS NULL OR section = $2)
       AND ($3::text IS NULL OR name ILIKE '%' || $3 || '%' OR code ILIKE '%' || $3 || '%')
     ORDER BY grade, section, name`,
    [f.grade || null, f.section || null, f.q || null]);
  return rows;
}

export async function get(user: AuthUser, id: number) {
  if (user.role === 'student' && user.studentId !== id)
    throw new HttpError(403, 'غير مصرح بالوصول لهذه البيانات');
  const { rows } = await q('SELECT * FROM students WHERE id = $1', [id]);
  if (!rows[0]) throw new HttpError(404, 'الطالبة غير موجودة');
  return rows[0];
}

async function assertNew(name: any, grade: any, section: any) {
  if (!name || !String(name).trim()) throw new HttpError(400, 'اسم الطالبة مطلوب');
  if (!grade || !section) throw new HttpError(400, 'الصف والشعبة مطلوبان');
}

export async function create(b: any, userId: number) {
  await assertNew(b.name, b.grade, b.section);
  const manual = b.code && String(b.code).trim();
  const code = manual ? String(b.code).trim() : 'TMP-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
  let s: any;
  try {
    const { rows } = await q(
      'INSERT INTO students(code, name, grade, section, notes) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [code, String(b.name).trim(), b.grade, b.section, b.notes || null]);
    s = rows[0];
  } catch (e: any) {
    if (e.code === '23505') throw new HttpError(409, 'هذا الرمز مستخدم مسبقاً');
    throw e;
  }
  if (!manual) await q("UPDATE students SET code = 'ST-' || lpad(id::text, 3, '0') WHERE id = $1", [s.id]);
  return { ...s, code: manual ? s.code : 'ST-' + String(s.id).padStart(3, '0') };
}

export async function update(id: number, b: any) {
  const { rows } = await q(
    `UPDATE students SET
       name    = COALESCE($2, name),
       grade   = COALESCE($3, grade),
       section = COALESCE($4, section),
       notes   = COALESCE($5, notes),
       active  = COALESCE($6, active)
     WHERE id = $1 RETURNING *`,
    [id, b.name ?? null, b.grade ?? null, b.section ?? null, b.notes ?? null, b.active ?? null]);
  if (!rows[0]) throw new HttpError(404, 'الطالبة غير موجودة');
  return rows[0];
}

export async function remove(id: number) {
  const { rows } = await q('DELETE FROM students WHERE id = $1 RETURNING id, name', [id]);
  if (!rows[0]) throw new HttpError(404, 'الطالبة غير موجودة');
  return rows[0];
}

/** استيراد جماعي: يتجاهل المكرر (اسم + صف + شعبة) ويرجع الإحصاء */
export async function importRows(rowsIn: any[]) {
  if (!Array.isArray(rowsIn) || !rowsIn.length) throw new HttpError(400, 'لا توجد صفوف للاستيراد');
  let added = 0, skipped = 0;
  for (const r of rowsIn.slice(0, 1000)) {
    const name = String(r.name ?? '').trim();
    const grade = String(r.grade ?? '').trim();
    const section = String(r.section ?? '').trim();
    if (!name || !grade || !section) { skipped++; continue; }
    const ex = await q('SELECT 1 FROM students WHERE name = $1 AND grade = $2 AND section = $3', [name, grade, section]);
    if (ex.rowCount) { skipped++; continue; }
    const ins = await q(
      "INSERT INTO students(code, name, grade, section) VALUES ('TMP-' || md5(random()::text), $1,$2,$3) RETURNING id",
      [name, grade, section]);
    await q("UPDATE students SET code = 'ST-' || lpad(id::text, 3, '0') WHERE id = $1", [ins.rows[0].id]);
    added++;
  }
  return { added, skipped };
}
