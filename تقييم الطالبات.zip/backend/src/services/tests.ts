import { q, pool } from '../database/pool';
import { HttpError } from '../middleware/errors';
import { AuthUser } from '../middleware/auth';

const norm = (r: any) => ({ ...r, score: r.score == null ? null : Number(r.score), max_score: Number(r.max_score) });

export async function list(user: AuthUser, f: { kind?: string; grade?: string; section?: string }) {
  if (user.role === 'student') {
    const sid = user.studentId!;
    const { rows } = await q(
      `SELECT t.id, t.title, t.kind, t.max_score, t.test_date, r.score, r.note
       FROM tests t
       LEFT JOIN results r ON r.test_id = t.id AND r.student_id = $1
       WHERE t.grade = (SELECT grade FROM students WHERE id = $1)
         AND t.section = (SELECT section FROM students WHERE id = $1)
         AND ($2::text IS NULL OR t.kind = $2)
       ORDER BY t.test_date DESC, t.id DESC`, [sid, f.kind || null]);
    return rows.map(norm);
  }
  const { rows } = await q(
    `SELECT t.*, (SELECT count(*) FROM results r WHERE r.test_id = t.id) AS results_count
     FROM tests t
     WHERE ($1::text IS NULL OR t.kind = $1) AND ($2::text IS NULL OR t.grade = $2) AND ($3::text IS NULL OR t.section = $3)
     ORDER BY t.test_date DESC, t.id DESC`, [f.kind || null, f.grade || null, f.section || null]);
  return rows.map(norm);
}

export async function create(user: AuthUser, b: any) {
  if (!b.title || !String(b.title).trim()) throw new HttpError(400, 'عنوان الاختبار مطلوب');
  if (!['test', 'nafis'].includes(b.kind)) throw new HttpError(400, 'نوع الاختبار غير صالح');
  const max = Number(b.max_score);
  if (!Number.isFinite(max) || max <= 0) throw new HttpError(400, 'الدرجة العظمى غير صالحة');
  if (!b.grade || !b.section) throw new HttpError(400, 'الصف والشعبة مطلوبان');
  const { rows } = await q(
    `INSERT INTO tests(title, kind, max_score, test_date, grade, section, created_by)
     VALUES ($1,$2,$3, COALESCE($4::date, CURRENT_DATE), $5,$6,$7) RETURNING *`,
    [String(b.title).trim(), b.kind, max, b.test_date || null, b.grade, b.section, user.id]);
  return norm(rows[0]);
}

export async function saveResults(user: AuthUser, testId: number, rowsIn: any[]) {
  const t = await q('SELECT * FROM tests WHERE id = $1', [testId]);
  if (!t.rows[0]) throw new HttpError(404, 'الاختبار غير موجود');
  const max = Number(t.rows[0].max_score);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const r of rowsIn ?? []) {
      const sid = Number(r.student_id), sc = Number(r.score);
      if (!sid || !Number.isFinite(sc) || sc < 0 || sc > max)
        throw new HttpError(400, 'درجة غير صالحة (تأكدي أنها بين 0 والدرجة العظمى)');
      await client.query(
        `INSERT INTO results(test_id, student_id, score, note) VALUES ($1,$2,$3,$4)
         ON CONFLICT (test_id, student_id) DO UPDATE SET score = EXCLUDED.score, note = EXCLUDED.note, updated_at = now()`,
        [testId, sid, sc, r.note || null]);
    }
    await client.query('COMMIT');
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
  return { saved: (rowsIn ?? []).length, test_id: testId, updated_by: user.id };
}

export async function remove(id: number) {
  const { rows } = await q('DELETE FROM tests WHERE id = $1 RETURNING id', [id]);
  if (!rows[0]) throw new HttpError(404, 'الاختبار غير موجود');
  return rows[0];
}
