import fs from 'fs';
import path from 'path';
import { q } from '../database/pool';
import { env } from '../config';
import { AuthUser } from '../middleware/auth';

export async function register(f: {
  stored_name: string; original_name: string; mime: string; size: number; kind: string;
  student_id: number | null; worksheet_id: number | null; achievement_id: number | null; uploaded_by: number;
}) {
  const { rows } = await q(
    `INSERT INTO files(stored_name, original_name, mime, size_bytes, kind, student_id, worksheet_id, achievement_id, uploaded_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
    [f.stored_name, f.original_name, f.mime, f.size, f.kind, f.student_id, f.worksheet_id, f.achievement_id, f.uploaded_by]);
  return rows[0];
}

export async function getForDownload(id: number) {
  const { rows } = await q(
    'SELECT f.*, a.visible AS achievement_visible FROM files f LEFT JOIN achievements a ON a.id = f.achievement_id WHERE f.id = $1',
    [id]);
  return rows[0] ?? null;
}

/** قاعدة الوصول: الطالبة تصل فقط لملفها الخاص، أو ورقة عمل صفية، أو مرفق إنجاز معلن، أو شعار — غير ذلك 404 بلا كشف */
export function accessible(user: AuthUser, f: any): boolean {
  if (user.role !== 'student') return true;
  if (f.kind === 'logo') return true; // شعارا المدرسة والوزارة غير حساسان
  if (f.student_id != null) return f.student_id === user.studentId;
  if (f.kind === 'worksheet') return true;
  if (f.kind === 'achievement') return !!f.achievement_visible;
  return false;
}

export function unlinkSafe(storedName: string) {
  try { fs.unlinkSync(path.join(env.uploadDirAbs, storedName)); } catch { /* الملف غير موجود — لا مشكلة */ }
}

export async function deleteFor(column: 'achievement_id' | 'worksheet_id', id: number) {
  const { rows } = await q(`DELETE FROM files WHERE ${column} = $1 RETURNING stored_name`, [id]);
  for (const r of rows) unlinkSafe(r.stored_name);
}
