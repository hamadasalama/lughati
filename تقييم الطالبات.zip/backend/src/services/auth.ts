import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { env } from '../config';
import { q } from '../database/pool';
import { HttpError } from '../middleware/errors';

// حد بسيط ضد التخمين: 5 محاولات فاشلة → قفل 15 دقيقة لنفس اسم المستخدم
const fails = new Map<string, { n: number; until: number }>();

export const hashPassword = (plain: string) => bcrypt.hash(plain, 10);
export const verifyPassword = (plain: string, hash: string) => bcrypt.compare(plain, hash);

export async function login(username: string, password: string) {
  const key = String(username ?? '').trim().toLowerCase();
  const f = fails.get(key);
  // القفل فعّال طوال مدته بغض النظر عن العدّاد
  if (f && f.until > Date.now())
    throw new HttpError(429, 'تم تجاوز عدد المحاولات المسموح، حاولي بعد قليل');
  const { rows } = await q<any>(
    'SELECT id, username, password_hash, role, active, token_version, student_id FROM users WHERE lower(username) = $1',
    [key]);
  const u = rows[0];
  if (!u || !(await verifyPassword(String(password ?? ''), u.password_hash))) {
    const c = fails.get(key) ?? { n: 0, until: 0 };
    c.n++;
    if (c.n >= 5) { c.until = Date.now() + 15 * 60 * 1000; c.n = 0; }
    fails.set(key, c);
    throw new HttpError(401, 'اسم المستخدم أو كلمة المرور غير صحيحة');
  }
  if (!u.active) throw new HttpError(403, 'هذا الحساب موقوف، يرجى مراجعة المعلمة');
  fails.delete(key);
  const token = jwt.sign({ uid: u.id, tv: u.token_version }, env.jwtSecret, { expiresIn: '8h' });
  return { token, user: { id: u.id, username: u.username, role: u.role, student_id: u.student_id } };
}

export async function changePassword(userId: number, newPassword: string, current?: string, requireCurrent = false) {
  const { rows } = await q<{ password_hash: string }>('SELECT password_hash FROM users WHERE id = $1', [userId]);
  if (!rows[0]) throw new HttpError(404, 'المستخدم غير موجود');
  if (requireCurrent) {
    if (!current) throw new HttpError(400, 'أدخلي كلمة المرور الحالية');
    if (!(await verifyPassword(current, rows[0].password_hash))) throw new HttpError(400, 'كلمة المرور الحالية غير صحيحة');
  }
  if (!newPassword || String(newPassword).length < 6) throw new HttpError(400, 'كلمة المرور يجب ألا تقل عن 6 أحرف');
  await q('UPDATE users SET password_hash = $1, token_version = token_version + 1 WHERE id = $2',
    [await hashPassword(newPassword), userId]);
}
