import { Router } from 'express';
import * as c from '../controllers/worksheets';
import { requireAuth, requireRole } from '../middleware/auth';
import { upload } from '../middleware/upload';

const r = Router();
r.use(requireAuth);
r.get('/', requireRole('teacher', 'admin', 'student'), c.list);
r.post('/', requireRole('teacher'), upload.single('file'), c.create);
r.patch('/:id/status', requireRole('teacher'), c.setStatus);
r.delete('/:id', requireRole('teacher'), c.remove);
export default r;
