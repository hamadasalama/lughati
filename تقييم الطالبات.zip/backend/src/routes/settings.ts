import { Router } from 'express';
import * as c from '../controllers/settings';
import { requireAuth, requireRole } from '../middleware/auth';
import { upload } from '../middleware/upload';

const r = Router();
r.use(requireAuth);
r.get('/', c.get);                                   // التسميات والشعارات يحتاجها الجميع
r.put('/', requireRole('teacher'), c.put);
r.post('/logo', requireRole('teacher'), upload.single('logo'), c.logo);
export default r;
