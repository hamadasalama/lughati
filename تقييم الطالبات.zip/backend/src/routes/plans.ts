import { Router } from 'express';
import * as c from '../controllers/plans';
import { requireAuth, requireRole } from '../middleware/auth';

const r = Router();
r.use(requireAuth);
r.get('/', requireRole('teacher', 'admin', 'student'), c.list);
r.post('/', requireRole('teacher'), c.create);
r.patch('/:id', requireRole('teacher'), c.update);
r.post('/:id/followups', requireRole('teacher'), c.addFollowup);
r.delete('/:id', requireRole('teacher'), c.remove);
export default r;
