import { Router } from 'express';
import * as c from '../controllers/files';
import { requireAuth } from '../middleware/auth';

const r = Router();
r.use(requireAuth);
r.get('/:id', c.download); // فحص الملكية داخل الخدمة لكل من يطلب
export default r;
