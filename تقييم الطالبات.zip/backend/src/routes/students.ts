import { Router } from 'express';
import * as c from '../controllers/students';
import { requireAuth, requireRole } from '../middleware/auth';

const r = Router();
r.use(requireAuth);
r.get('/', requireRole('teacher', 'admin'), c.list);
r.get('/:id', requireRole('teacher', 'admin', 'student'), c.get); // الطالبة: نفسها فقط (يُفرض داخل الخدمة)
r.post('/', requireRole('teacher'), c.create);
r.post('/import', requireRole('teacher'), c.importRows);
r.patch('/:id', requireRole('teacher'), c.update);
r.delete('/:id', requireRole('teacher'), c.remove);
export default r;
