import { Router } from 'express';
import * as c from '../controllers/skills';
import { requireAuth, requireRole } from '../middleware/auth';

const r = Router();
r.use(requireAuth);
r.get('/', requireRole('teacher', 'admin', 'student'), c.list);
r.post('/', requireRole('teacher'), c.create);
r.put('/:id/levels', requireRole('teacher'), c.setLevels);
r.delete('/:id', requireRole('teacher'), c.remove);
export default r;
