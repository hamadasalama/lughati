import { Router } from 'express';
import * as c from '../controllers/tests';
import { requireAuth, requireRole } from '../middleware/auth';

const r = Router();
r.use(requireAuth);
r.get('/', requireRole('teacher', 'admin', 'student'), c.list);
r.post('/', requireRole('teacher'), c.create);
r.put('/:id/results', requireRole('teacher'), c.saveResults);
r.delete('/:id', requireRole('teacher'), c.remove);
export default r;
