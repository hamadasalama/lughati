import { Router } from 'express';
import * as c from '../controllers/achievements';
import { requireAuth, requireRole } from '../middleware/auth';
import { upload } from '../middleware/upload';

const r = Router();
r.use(requireAuth);
r.get('/', requireRole('teacher', 'admin', 'student'), c.list); // الطالبة ترى المعلن فقط
r.post('/', requireRole('teacher'), upload.array('files', 10), c.create);
r.patch('/:id', requireRole('teacher'), c.update);
r.delete('/:id', requireRole('teacher'), c.remove);
export default r;
