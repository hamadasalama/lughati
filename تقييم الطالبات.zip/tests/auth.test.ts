import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import { app, ensureReady, asTeacher, pool } from './helpers';

beforeAll(() => ensureReady());

describe('الاتصال الفعلي بقاعدة البيانات', () => {
  it('GET /api/health يتحقق من اتصال PostgreSQL حقيقياً', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.db).toBe('ok');
    expect(res.body.now).toBeTruthy();
  });
  it('استعلام مباشر يعمل', async () => {
    const r = await pool.query('SELECT count(*)::int AS n FROM users');
    expect(r.rows[0].n).toBeGreaterThanOrEqual(3);
  });
});

describe('المصادقة', () => {
  it('دخول صحيح يعيد المستخدم ويضع كوكي جلسة', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: 'teacher1', password: 'teacher-pass' });
    expect(res.status).toBe(200);
    expect(res.body.user.role).toBe('teacher');
    expect(res.headers['set-cookie']).toBeTruthy();
  });
  it('دخول بكلمة مرور خاطئة ← 401', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: 'teacher1', password: 'wrong' });
    expect(res.status).toBe(401);
  });
  it('كلمة المرور لا تُعاد أبداً في أي استجابة', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: 'teacher1', password: 'teacher-pass' });
    expect(JSON.stringify(res.body)).not.toContain('password_hash');
  });
  it('مسار محمي بدون جلسة ← 401', async () => {
    const res = await request(app).get('/api/students');
    expect(res.status).toBe(401);
  });
  it('GET /api/auth/me بجلسة سليمة يعرف صاحبة الجلسة', async () => {
    const cookie = await asTeacher();
    const res = await request(app).get('/api/auth/me').set('Cookie', cookie);
    expect(res.status).toBe(200);
    expect(res.body.user.username).toBe('teacher1');
  });
});
