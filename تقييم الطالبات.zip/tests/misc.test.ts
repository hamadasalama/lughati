import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import { app, ensureReady, asTeacher, asStudentA } from './helpers';

beforeAll(() => ensureReady());

describe('نجم الأسبوع (أميرتي هذا الأسبوع)', () => {
  it('المعلمة تختار نجمة الأسبوع ويُطبق قاعدة الأحد، وإعادة الاختيار تحدّث نفس الأسبوع', async () => {
    const cookie = await asTeacher();
    const r1 = await request(app).put('/api/star').set('Cookie', cookie)
      .send({ date: '2025-01-08', student_id: 1, reason: 'مشاركة متميزة' }); // أربعاء ← أسبوع يبدأ 2025-01-05
    expect(r1.status).toBe(200);
    expect(r1.body.week_start).toBe('2025-01-05');
    const r2 = await request(app).put('/api/star').set('Cookie', cookie)
      .send({ date: '2025-01-09', student_id: 2, reason: 'أُعيد الاختيار' });
    expect(r2.body.week_start).toBe('2025-01-05');
    const all = await request(app).get('/api/star').set('Cookie', cookie);
    const week = all.body.filter((s: any) => s.week_start === '2025-01-05');
    expect(week.length).toBe(1); // نجمة واحدة لكل أسبوع
  });
  it('النجمة الحالية مرئية للطالبة', async () => {
    const cookie = await asStudentA();
    const res = await request(app).get('/api/star/current').set('Cookie', cookie);
    expect(res.status).toBe(200);
  });
});

describe('إدارة الحسابات', () => {
  it('المعلمة تنشئ حساب طالبة مرتبطاً برمزها الثابت', async () => {
    const cookie = await asTeacher();
    const res = await request(app).post('/api/users').set('Cookie', cookie)
      .send({ username: 'st001', password: 'secret123', role: 'student', student_id: 1 });
    expect(res.status).toBe(201);
    expect(res.body.student_id).toBe(1);
  });
  it('ربط الحساب بطالبة لها حساب بالفعل ← 409، واسم مستخدم مكرر ← 409', async () => {
    const cookie = await asTeacher();
    const dupStudent = await request(app).post('/api/users').set('Cookie', cookie)
      .send({ username: 'another', password: 'secret123', role: 'student', student_id: 1 });
    expect(dupStudent.status).toBe(409);
    const dupUser = await request(app).post('/api/users').set('Cookie', cookie)
      .send({ username: 'st001', password: 'secret123', role: 'student', student_id: 2 });
    expect(dupUser.status).toBe(409);
  });
  it('الطالبة تغير كلمتها فتُبطَل الجلسات القديمة (token_version)', async () => {
    const cookie = await asStudentA();
    const ch = await request(app).post('/api/auth/change-password').set('Cookie', cookie)
      .send({ current: 'student-pass', new: 'new-pass-123' });
    expect(ch.status).toBe(200);
    const old = await request(app).get('/api/auth/me').set('Cookie', cookie);
    expect(old.status).toBe(401);
  });
});
