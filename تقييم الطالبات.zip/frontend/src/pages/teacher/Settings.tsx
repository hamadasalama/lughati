import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, ApiError } from '../../api/client';
import type { Settings } from '../../api/types';
import { useToast } from '../../components/ui';

const SCALE_ROWS: [string, string][] = [
  ['l5', 'تسمية الدرجة 5'],
  ['l4', 'تسمية الدرجة 4'],
  ['l3', 'تسمية الدرجة 3'],
  ['l2', 'تسمية الدرجة 2'],
  ['l1', 'تسمية الدرجة 1'],
];

export default function Settings() {
  const [cfg, setCfg] = useState<Settings>({});
  const [form, setForm] = useState<any>(null);
  const [pw, setPw] = useState({ current: '', nw: '', confirm: '' });
  const { push } = useToast();
  const nav = useNavigate();

  useEffect(() => {
    api('/settings').then((c) => {
      setCfg(c);
      setForm({
        schoolName: c.schoolName ?? '',
        eduAdmin: c.eduAdmin ?? '',
        principal: c.principal ?? '',
        teacher: c.teacher ?? '',
        grades: Array.isArray(c.grades) ? c.grades.join('، ') : '',
        classes: Array.isArray(c.classes) ? c.classes.join('، ') : '',
        l5: c.scale?.labels?.['5'] ?? '',
        l4: c.scale?.labels?.['4'] ?? '',
        l3: c.scale?.labels?.['3'] ?? '',
        l2: c.scale?.labels?.['2'] ?? '',
        l1: c.scale?.labels?.['1'] ?? '',
      });
    }).catch((e: any) => push(e.message || 'خطأ', true));
  }, [push]);

  if (!form) return <div className="empty">جارٍ التحميل…</div>;

  async function save(e: FormEvent) {
    e.preventDefault();
    const body = {
      schoolName: form.schoolName,
      eduAdmin: form.eduAdmin,
      principal: form.principal,
      teacher: form.teacher,
      grades: form.grades.split(/[،,]/).map((s: string) => s.trim()).filter(Boolean),
      classes: form.classes.split(/[،,]/).map((s: string) => s.trim()).filter(Boolean),
      scale: {
        max: 5,
        labels: { '5': form.l5, '4': form.l4, '3': form.l3, '2': form.l2, '1': form.l1 },
      },
    };
    try {
      await api('/settings', { method: 'PUT', body: JSON.stringify(body) });
      setCfg(await api('/settings'));
      push('تم حفظ الإعدادات');
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  async function uploadLogo(file: File | undefined, which: 'school' | 'moe') {
    if (!file) return;
    const fd = new FormData();
    fd.append('logo', file);
    fd.append('which', which);
    try {
      await api('/settings/logo', { method: 'POST', body: fd });
      setCfg(await api('/settings'));
      push('تم رفع الشعار');
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  async function changePw(e: FormEvent) {
    e.preventDefault();
    if (pw.nw !== pw.confirm) { push('كلمتا المرور غير متطابقتين', true); return; }
    try {
      await api('/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ current: pw.current, new: pw.nw }),
      });
      push('تم تغيير كلمة المرور — جارٍ تحويلك لتسجيل الدخول…');
      setTimeout(() => nav('/login'), 1200);
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  return (
    <div>
      <div className="page-head"><h2>الإعدادات</h2></div>

      <form className="card" onSubmit={save}>
        <h3>بيانات المدرسة</h3>
        <div className="form-grid">
          <div className="fld">
            <label>اسم المدرسة</label>
            <input value={form.schoolName} onChange={(e) => setForm({ ...form, schoolName: e.target.value })} />
          </div>
          <div className="fld">
            <label>الإدارة التعليمية</label>
            <input value={form.eduAdmin} onChange={(e) => setForm({ ...form, eduAdmin: e.target.value })} />
          </div>
          <div className="fld">
            <label>مديرة المدرسة</label>
            <input value={form.principal} onChange={(e) => setForm({ ...form, principal: e.target.value })} />
          </div>
          <div className="fld">
            <label>معلمة المادة</label>
            <input value={form.teacher} onChange={(e) => setForm({ ...form, teacher: e.target.value })} />
          </div>
          <div className="fld">
            <label>الصفوف (مفصولة بفاصلة)</label>
            <input value={form.grades} onChange={(e) => setForm({ ...form, grades: e.target.value })} />
          </div>
          <div className="fld">
            <label>الشعب (مفصولة بفاصلة)</label>
            <input value={form.classes} onChange={(e) => setForm({ ...form, classes: e.target.value })} />
          </div>
        </div>

        <h3>تسميات سلّم التقييم (من 5 إلى 1)</h3>
        <div className="form-grid">
          {SCALE_ROWS.map(([k, hint]) => (
            <div className="fld" key={k}>
              <label>{hint}</label>
              <input value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
            </div>
          ))}
        </div>
        <button className="btn">حفظ الإعدادات</button>
      </form>

      <div className="card">
        <h3>الشعارات</h3>
        <div className="form-grid">
          <div className="fld">
            <label>شعار المدرسة</label>
            {cfg.logoSchool?.file_id ? (
              <img src={'/api/files/' + cfg.logoSchool.file_id} alt="شعار المدرسة" style={{ maxHeight: 64, marginBottom: 6 }} />
            ) : (
              <span className="badge" style={{ marginBottom: 6 }}>لا شعار</span>
            )}
            <input type="file" accept="image/*" onChange={(e) => uploadLogo(e.target.files?.[0], 'school')} />
          </div>
          <div className="fld">
            <label>شعار وزارة التعليم</label>
            {cfg.logoMoe?.file_id ? (
              <img src={'/api/files/' + cfg.logoMoe.file_id} alt="شعار وزارة التعليم" style={{ maxHeight: 64, marginBottom: 6 }} />
            ) : (
              <span className="badge" style={{ marginBottom: 6 }}>لا شعار</span>
            )}
            <input type="file" accept="image/*" onChange={(e) => uploadLogo(e.target.files?.[0], 'moe')} />
          </div>
        </div>
      </div>

      <form className="card" onSubmit={changePw}>
        <h3>تغيير كلمة المرور</h3>
        <div className="form-grid">
          <div className="fld">
            <label>كلمة المرور الحالية</label>
            <input type="password" value={pw.current} required onChange={(e) => setPw({ ...pw, current: e.target.value })} />
          </div>
          <div className="fld">
            <label>كلمة المرور الجديدة</label>
            <input type="password" value={pw.nw} required onChange={(e) => setPw({ ...pw, nw: e.target.value })} />
          </div>
          <div className="fld">
            <label>تأكيد كلمة المرور الجديدة</label>
            <input type="password" value={pw.confirm} required onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
          </div>
        </div>
        <p className="muted">بعد التغيير ستحتاجين إلى تسجيل الدخول من جديد.</p>
        <button className="btn">تغيير كلمة المرور</button>
      </form>
    </div>
  );
}
