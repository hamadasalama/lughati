import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError, qs } from '../../api/client';
import type { Student } from '../../api/types';
import Icon from '../../components/Icon';
import { Modal, useToast } from '../../components/ui';

const EMPTY = { name: '', grade: 'الرابع', section: 'أ', code: '', notes: '' };

export default function Students() {
  const [rows, setRows] = useState<Student[]>([]);
  const [grades, setGrades] = useState<string[]>(['الرابع', 'الخامس', 'السادس']);
  const [sections, setSections] = useState<string[]>(['أ', 'ب']);
  const [grade, setGrade] = useState('');
  const [section, setSection] = useState('');
  const [q, setQ] = useState('');
  const [edit, setEdit] = useState<any>(null);
  const [isNew, setIsNew] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState('');
  const { push } = useToast();

  const load = useCallback(async () => {
    setRows(await api('/students' + qs({ grade, section, q })));
  }, [grade, section, q]);

  useEffect(() => { load().catch((e: any) => push(e.message || 'خطأ', true)); }, [load, push]);

  useEffect(() => {
    api('/settings').then((cfg) => {
      if (Array.isArray(cfg.grades) && cfg.grades.length) setGrades(cfg.grades);
      if (Array.isArray(cfg.classes) && cfg.classes.length) setSections(cfg.classes);
    }).catch(() => {});
  }, []);

  async function save(e: FormEvent) {
    e.preventDefault();
    const payload: any = { name: edit.name, grade: edit.grade, section: edit.section, notes: edit.notes };
    if (isNew && edit.code) payload.code = edit.code;
    try {
      if (isNew) {
        await api('/students', { method: 'POST', body: JSON.stringify(payload) });
        push('تمت إضافة الطالبة');
      } else {
        await api('/students/' + edit.id, { method: 'PATCH', body: JSON.stringify(payload) });
        push('تم حفظ التعديلات');
      }
      setEdit(null);
      load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  async function remove(s: Student) {
    if (!confirm('سيُحذف مع كل سجلاتها (تقييمات، اختبارات، رسائل…). هل أنت متأكدة؟')) return;
    try {
      await api('/students/' + s.id, { method: 'DELETE' });
      push('تم حذف ' + s.name);
      load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  async function doImport() {
    const lines = importText.split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));
    const rowsIn = lines
      .map((l) => {
        const parts = l.split(/[,;\t،]/).map((p) => p.trim());
        return { name: parts[0] || '', grade: parts[1] || 'الرابع', section: parts[2] || 'أ' };
      })
      .filter((r) => r.name);
    if (!rowsIn.length) { push('لا توجد أسماء صالحة للاستيراد', true); return; }
    try {
      const res = await api('/students/import', { method: 'POST', body: JSON.stringify({ rows: rowsIn }) });
      push(`أُضيف ${res.added}، وتخطي ${res.skipped} (مكرر)`);
      setShowImport(false);
      setImportText('');
      load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  return (
    <div>
      <div className="page-head">
        <h2>الطالبات</h2>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn ghost" onClick={() => setShowImport(true)}>
            <Icon name="plus" size={15} /> استيراد سريع
          </button>
          <button className="btn" onClick={() => { setEdit({ ...EMPTY }); setIsNew(true); }}>
            <Icon name="plus" size={15} /> طالبة جديدة
          </button>
        </div>
      </div>

      <div className="toolbar">
        <div className="fld">
          <label>الصف</label>
          <select value={grade} onChange={(e) => setGrade(e.target.value)}>
            <option value="">كل الصفوف</option>
            {grades.map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
        </div>
        <div className="fld">
          <label>الشعبة</label>
          <select value={section} onChange={(e) => setSection(e.target.value)}>
            <option value="">كل الشعب</option>
            {sections.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div className="fld" style={{ flex: 1 }}>
          <label>بحث بالاسم أو الرمز</label>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="اكتبي جزءاً من الاسم…" />
        </div>
      </div>

      <div className="card">
        {rows.length === 0 ? (
          <div className="empty">لا توجد طالبات مطابقات — أضيفي أول طالبة أو استخدمي الاستيراد السريع.</div>
        ) : (
          <table>
            <thead>
              <tr><th>الرمز</th><th>الاسم</th><th>الصف</th><th>الشعبة</th><th>إجراءات</th></tr>
            </thead>
            <tbody>
              {rows.map((s) => (
                <tr key={s.id}>
                  <td className="num">{s.code}</td>
                  <td>
                    <Link to={'/students/' + s.id}>{s.name}</Link>
                    {!s.active && <> <span className="badge warn">موقوفة</span></>}
                  </td>
                  <td>{s.grade}</td>
                  <td>{s.section}</td>
                  <td>
                    <div className="row-actions">
                      <Link className="btn ghost sm" to={'/students/' + s.id}>السجل</Link>
                      <button
                        className="btn ghost sm"
                        onClick={() => {
                          setEdit({ id: s.id, name: s.name, grade: s.grade, section: s.section, notes: s.notes || '' });
                          setIsNew(false);
                        }}
                      >
                        تعديل
                      </button>
                      <button className="btn danger sm" onClick={() => remove(s)}>حذف</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {edit && (
        <Modal title={isNew ? 'إضافة طالبة' : 'تعديل بيانات طالبة'} onClose={() => setEdit(null)}>
          <form onSubmit={save}>
            <div className="form-grid">
              <div className="fld full">
                <label>اسم الطالبة</label>
                <input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} required />
              </div>
              <div className="fld">
                <label>الصف</label>
                <select value={edit.grade} onChange={(e) => setEdit({ ...edit, grade: e.target.value })}>
                  {grades.map((g) => <option key={g}>{g}</option>)}
                </select>
              </div>
              <div className="fld">
                <label>الشعبة</label>
                <select value={edit.section} onChange={(e) => setEdit({ ...edit, section: e.target.value })}>
                  {sections.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
              {isNew && (
                <div className="fld">
                  <label>الرمز (اختياري — يُولَّد تلقائياً)</label>
                  <input value={edit.code} onChange={(e) => setEdit({ ...edit, code: e.target.value })} placeholder="ST-001" />
                </div>
              )}
              <div className="fld full">
                <label>ملاحظات</label>
                <textarea value={edit.notes || ''} onChange={(e) => setEdit({ ...edit, notes: e.target.value })} />
              </div>
            </div>
            <button className="btn">حفظ</button>
          </form>
        </Modal>
      )}

      {showImport && (
        <Modal title="استيراد سريع للأسماء" onClose={() => setShowImport(false)}>
          <p className="muted" style={{ fontSize: 15 }}>
            كل سطر: <b>الاسم، الصف، الشعبة</b> — الصف والشعبة اختياريان (الافتراضي: الرابع / أ).
            مثال: <code>نورة العتيبي، الخامس، ب</code>
          </p>
          <textarea
            style={{ minHeight: 180 }}
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            placeholder={'سارة القحطاني\nريم الشمري، الخامس، ب'}
          />
          <button className="btn" onClick={doImport}>استيراد</button>
        </Modal>
      )}
    </div>
  );
}
