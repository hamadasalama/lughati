import { useEffect, useState } from 'react';
import { api } from '../../api/client';
import { useToast } from '../../components/ui';

function pick(row: any, keys: string[]): any {
  for (const k of keys) {
    if (row[k] !== undefined && row[k] !== null && row[k] !== '') return row[k];
  }
  return null;
}

function colorForScore(v: number): string {
  return v >= 4.5 ? '#1a5c42' : v >= 3.5 ? '#4c8a63' : v >= 2.5 ? '#c9a23f' : v >= 1.5 ? '#cf8a4a' : '#b8503c';
}

function rowAvg(r: any, keys: string[]): number | null {
  const v = pick(r, keys);
  return v == null || v === '' ? null : Number(v);
}

function avgOfRow(r: any): number | null {
  const xs = [
    rowAvg(r, ['behavior', 'behavior_avg']),
    rowAvg(r, ['participation', 'participation_avg']),
    rowAvg(r, ['homework', 'homework_avg']),
  ].filter((x): x is number => x != null && !Number.isNaN(x));
  return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null;
}

function trendBadge(r: any) {
  const t = r?.trend;
  if (!t || !t.enough) return <span className="muted">—</span>;
  const s = Number(t.slope);
  if (s > 0) return <span className="badge ok">↑ تتحسن</span>;
  if (s < 0) return <span className="badge warn">↓ تحتاج تعزيزاً</span>;
  return <span className="badge">→ مستقرة</span>;
}

function HeatCell({ v, plain }: { v: number | null; plain?: boolean }) {
  if (v == null || Number.isNaN(v)) return <td className="num" style={{ color: 'var(--mut)' }}>—</td>;
  if (plain) return <td className="num"><b>{v.toFixed(2)}</b></td>;
  const bg = colorForScore(v);
  return (
    <td
      className="num"
      style={{ background: bg, color: '#fff', printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' } as any}
    >
      {v.toFixed(2)}
    </td>
  );
}

export default function Analytics() {
  const [rows, setRows] = useState<any[] | null>(null);
  const [err, setErr] = useState('');
  const [grade, setGrade] = useState('');
  const [section, setSection] = useState('');
  const [grades, setGrades] = useState<string[]>(['الرابع', 'الخامس', 'السادس']);
  const [sections, setSections] = useState<string[]>(['أ', 'ب']);
  const { push } = useToast();

  useEffect(() => {
    api('/reports/summary')
      .then((d: any) => setRows(Array.isArray(d) ? d : Array.isArray(d?.rows) ? d.rows : []))
      .catch((e: any) => setErr(e.message || 'خطأ'));
    api('/settings').then((c) => {
      if (Array.isArray(c.grades) && c.grades.length) setGrades(c.grades);
      if (Array.isArray(c.classes) && c.classes.length) setSections(c.classes);
    }).catch(() => {});
  }, []);

  if (err) return <div className="card"><div className="empty">{err}</div></div>;
  if (rows === null) return <div className="empty">جارٍ التحميل…</div>;

  const view = rows.filter((r) =>
    (!grade || String(pick(r, ['grade'])) === grade) &&
    (!section || String(pick(r, ['section'])) === section)
  );

  const tot = { present: 0, excused: 0, absent: 0 };
  for (const r of rows) {
    tot.present += Number(pick(r, ['present', 'present_count'])) || 0;
    tot.excused += Number(pick(r, ['excused', 'excused_count'])) || 0;
    tot.absent += Number(pick(r, ['absent', 'absent_count'])) || 0;
  }

  function overall(m: string, alt: string): string {
    let s = 0, c = 0;
    for (const r of rows!) {
      const v = pick(r, [m, alt]);
      const n = Number(pick(r, ['present', 'present_count'])) || 0;
      if (v != null && v !== '' && n > 0) { s += Number(v) * n; c += n; }
    }
    return c ? (s / c).toFixed(2) : '—';
  }

  return (
    <div>
      <div className="page-head"><h2>التقارير والتحليلات</h2></div>

      <div className="grid4">
        <div className="stat"><div className="v">{tot.present}</div><div className="k">تقييمات بحضور</div></div>
        <div className="stat"><div className="v">{tot.excused}</div><div className="k">غياب بعذر</div></div>
        <div className="stat"><div className="v">{tot.absent}</div><div className="k">غياب</div></div>
        <div className="stat"><div className="v">{overall('behavior', 'behavior_avg')}</div><div className="k">متوسط السلوك عامةً</div></div>
        <div className="stat"><div className="v">{overall('participation', 'participation_avg')}</div><div className="k">متوسط المشاركة عامةً</div></div>
        <div className="stat"><div className="v">{overall('homework', 'homework_avg')}</div><div className="k">متوسط الواجب عامةً</div></div>
      </div>

      <div className="toolbar">
        <div className="fld">
          <label>الصف</label>
          <select value={grade} onChange={(e) => setGrade(e.target.value)}>
            <option value="">كل الصفوف</option>
            {grades.map((g) => <option key={g}>{g}</option>)}
          </select>
        </div>
        <div className="fld">
          <label>الشعبة</label>
          <select value={section} onChange={(e) => setSection(e.target.value)}>
            <option value="">كل الشعب</option>
            {sections.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="card">
        <h3>خريطة الألوان — متوسطات الطالبات</h3>
        <p className="muted" style={{ fontSize: 14, marginTop: 0 }}>
          المتوسطات من التقييمات بحضور «حاضرة» فقط. الاتجاه يظهر بعد 4 تقييمات حاضرة على الأقل، وهو مؤشر استرشادي لا حكم نهائي.
        </p>
        {view.length === 0 ? (
          <div className="empty">لا بيانات مطابقة بعد.</div>
        ) : (
          <>
            <table>
              <thead>
                <tr>
                  <th>الطالبة</th><th>الصف/الشعبة</th>
                  <th>السلوك</th><th>المشاركة</th><th>الواجب</th><th>المتوسط</th><th>الاتجاه</th>
                </tr>
              </thead>
              <tbody>
                {view.map((r, i) => (
                  <tr key={i}>
                    <td>{String(pick(r, ['name', 'student_name']) ?? '')}</td>
                    <td>{String(pick(r, ['grade']) ?? '')}/{String(pick(r, ['section']) ?? '')}</td>
                    <HeatCell v={rowAvg(r, ['behavior', 'behavior_avg'])} />
                    <HeatCell v={rowAvg(r, ['participation', 'participation_avg'])} />
                    <HeatCell v={rowAvg(r, ['homework', 'homework_avg'])} />
                    <HeatCell v={avgOfRow(r)} plain />
                    <td>{trendBadge(r)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="muted" style={{ display: 'flex', gap: 12, flexWrap: 'wrap', fontSize: 13.5, marginTop: 10 }}>
              {[['4.5 فأعلى', '#1a5c42'], ['3.5 – 4.49', '#4c8a63'], ['2.5 – 3.49', '#c9a23f'], ['1.5 – 2.49', '#cf8a4a'], ['أقل من 1.5', '#b8503c']].map(([t, c]) => (
                <span key={t} style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                  <i style={{ width: 13, height: 13, borderRadius: 4, background: c, display: 'inline-block' }} />
                  {t}
                </span>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
