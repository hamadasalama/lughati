import { useEffect, useState, type FormEvent } from 'react';
import { api, ApiError } from '../../api/client';
import type { Student } from '../../api/types';
import Icon from '../../components/Icon';
import { Modal, useToast } from '../../components/ui';

export default function Plans() {
  const [rows, setRows] = useState<any[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [show, setShow] = useState(false);
  const [form, setForm] = useState<any>({ student_id: '', title: '', description: '' });
  const [edit, setEdit] = useState<any | null>(null);
  const [fup, setFup] = useState<any | null>(null);
  const [fnote, setFnote] = useState('');
  const { push } = useToast();

  async function load() {
    const [ps, stus] = await Promise.all([api('/plans'), api('/students')]);
    setRows(Array.isArray(ps) ? ps : []);
    setStudents(stus);
  }

  useEffect(() => { load().catch((e: any) => push(e.message || 'خطأ', true)); }, [push]);

  async function create(e: FormEvent) {
    e.preventDefault();
    if (!form.student_id) { push('اختاري الطالبة', true); return; }
    try {
      await api('/plans', {
        method: 'POST',
        body: JSON.stringify({ student_id: Number(form.student_id), title: form.title, description: form.description || '' }),
      });
      push('أُنشئت الخطة العلاجية');
      setShow(false);
      setForm({ student_id: '', title: '', description: '' });
      load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  async function saveEdit(e: FormEvent) {
    e.preventDefault();
    try {
      await api('/plans/' + edit.id, {
        method: 'PATCH',
        body: JSON.stringify({ title: edit.title, description: edit.description || '' }),
      });
      push('حُفظت التعديلات');
      setEdit(null);
      load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  async function toggle(p: any) {
    try {
      await api('/plans/' + p.id, {
        method: 'PATCH',
        body: JSON.stringify({ status: p.status === 'done' ? 'active' : 'done' }),
      });
      push(p.status === 'done' ? 'أُعيد تنشيط الخطة' : 'عُلّمت الخطة مكتملة');
      load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  async function addFup() {
    try {
      await api('/plans/' + fup.id + '/followups', { method: 'POST', body: JSON.stringify({ note: fnote.trim() }) });
      push('أُضيفت المتابعة');
      setFnote('');
      const fresh: any[] = await api('/plans');
      setRows(fresh);
      setFup(fresh.find((x) => x.id === fup.id) || null);
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'خطأ غير متوقع', true);
    }
  }

  const sname = (p: any) => p.student_name ?? p.name ?? ('#' + p.student_id);

  return (
    <div>
      <div className="page-head">
        <h2>الخطط العلاجية</h2>
        <button className="btn" onClick={() => { setForm({ student_id: '', title: '', description: '' }); setShow(true); }}>
          <Icon name="plus" size={15} /> خطة جديدة
        </button>
      </div>

      <div className="card">
        {rows.length === 0 ? <div className="empty">لا خطط علاجية بعد.</div> : (
          <table>
            <thead>
              <tr><th>الطالبة</th><th>الخطة</th><th>الحالة</th><th>المتابعات</th><th>إجراءات</th></tr>
            </thead>
            <tbody>
              {rows.map((p) => (
                <tr key={p.id}>
                  <td>{sname(p)}</td>
                  <td>
                    <b>{p.title}</b>
                    {p.description ? <div className="muted" style={{ fontSize: 14 }}>{p.description}</div> : null}
                  </td>
                  <td><span className={'badge ' + (p.status === 'done' ? 'ok' : 'warn')}>{p.status === 'done' ? 'مكتملة' : 'نشطة'}</span></td>
                  <td className="num">{Array.isArray(p.followups) ? p.followups.length : '—'}</td>
                  <td>
                    <div className="row-actions">
                      <button className="btn ghost sm" onClick={() => { setFnote(''); setFup(p); }}>متابعات</button>
                      <button className="btn ghost sm" onClick={() => setEdit({ ...p })}>تعديل</button>
                      <button className="btn ghost sm" onClick={() => toggle(p)}>{p.status === 'done' ? 'إعادة تنشيط' : 'إكمال'}</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {show && (
        <Modal title="خطة علاجية جديدة" onClose={() => setShow(false)}>
          <form onSubmit={create}>
            <div className="fld">
              <label>الطالبة</label>
              <select value={form.student_id} onChange={(e) => setForm({ ...form, student_id: e.target.value })} required>
                <option value="">اختاري…</option>
                {students.map((s) => <option key={s.id} value={s.id}>{s.name} — {s.grade}/{s.section}</option>)}
              </select>
            </div>
            <div className="fld">
              <label>عنوان الخطة</label>
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required placeholder="مثال: خطة تحسين الطلاقة القرائية" />
            </div>
            <div className="fld">
              <label>الوصف / الإجراءات</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <button className="btn">إنشاء الخطة</button>
          </form>
        </Modal>
      )}

      {edit && (
        <Modal title="تعديل الخطة" onClose={() => setEdit(null)}>
          <form onSubmit={saveEdit}>
            <div className="fld">
              <label>العنوان</label>
              <input value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} required />
            </div>
            <div className="fld">
              <label>الوصف / الإجراءات</label>
              <textarea value={edit.description || ''} onChange={(e) => setEdit({ ...edit, description: e.target.value })} />
            </div>
            <button className="btn">حفظ</button>
          </form>
        </Modal>
      )}

      {fup && (
        <Modal title={'متابعات — ' + fup.title} onClose={() => setFup(null)}>
          {Array.isArray(fup.followups) && fup.followups.length ? (
            fup.followups.map((f: any) => (
              <div key={f.id} style={{ marginBottom: 10 }}>
                {f.note}
                <div className="muted" style={{ fontSize: 12.5 }}>
                  {new Date(f.created_at).toLocaleString('ar', { dateStyle: 'short', timeStyle: 'short' } as Intl.DateTimeFormatOptions)}
                </div>
              </div>
            ))
          ) : <p className="muted">لا متابعات بعد.</p>}
          <div className="fld" style={{ marginTop: 10 }}>
            <label>متابعة جديدة</label>
            <textarea value={fnote} onChange={(e) => setFnote(e.target.value)} placeholder="ما تحقق بعد تنفيذ الخطة…" />
          </div>
          <button className="btn" disabled={!fnote.trim()} onClick={addFup}>إضافة المتابعة</button>
        </Modal>
      )}
    </div>
  );
}
