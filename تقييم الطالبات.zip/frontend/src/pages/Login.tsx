import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useToast } from '../components/ui';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const { setMe } = useAuth();
  const { push } = useToast();
  const nav = useNavigate();

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const me = await api('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
      setMe(me);
      push('مرحباً بك، ' + (me.name || me.username));
      nav(me.role === 'student' ? '/s_home' : '/students');
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'تعذر تسجيل الدخول', true);
      setBusy(false);
    }
  }

  return (
    <div className="login">
      <div className="l-right">
        <div className="q">«اللغة العربية بحرٌ لا ساحل له، ومن أتقن مفاتيحه أبحر بعقله.»</div>
        <div className="q">«كل طالبة تقرأ اليوم، تقود غداً.»</div>
        <div className="sig">
          <b>إعداد وتنفيذ: أ. مها الحمادي</b><br />
          مديرة المدرسة: أ. بدور الجارد
        </div>
      </div>
      <div className="l-left">
        <form className="login-card" onSubmit={submit}>
          <div className="lc-head">
            <div className="logo big">ل</div>
            <h2>منصة لغتي</h2>
            <p>تقييم طالبات مادة اللغة العربية</p>
          </div>
          <div className="fld">
            <label>اسم المستخدم</label>
            <input value={username} onChange={(e) => setUsername(e.target.value)} autoFocus required />
          </div>
          <div className="fld">
            <label>كلمة المرور</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <button className="btn" disabled={busy}>
            {busy ? 'جارٍ التحقق…' : 'تسجيل الدخول'}
          </button>
        </form>
      </div>
    </div>
  );
}
