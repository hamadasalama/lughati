# منصة لغتي — تقييم طالبات مادة اللغة العربية

تطبيق ويب متكامل (Full-Stack): واجهة React + TypeScript، خادم Node.js/Express + TypeScript،
قاعدة بيانات PostgreSQL حقيقية، مصادقة بجلسات آمنة وصلاحيات مفروضة في الخادم.

**إعداد وتنفيذ: أ. مها الحمادي**
مديرة المدرسة: أ. بدور الجارد

---

## المتطلبات
- Node.js 18 أو أحدث
- PostgreSQL 14 أو أحدث يعمل محلياً

## التشغيل للتطوير (كل الأوامر من جذر المشروع)

1) **تثبيت تبعيات المشروعين معاً** (npm workspaces — مرة واحدة فقط من الجذر):

       npm install

2) **إنشاء ملف البيئة**: انسخي `.env.example` إلى `.env` وعدّلي:
   - `DATABASE_URL`: بيانات اتصالك بـ PostgreSQL.
     تنبيه: كلمة مرور تحتوي رموزاً مثل `@` أو `:` تفسد الرابط — استخدمي حروفاً وأرقاماً فقط.
   - `JWT_SECRET`: أي نص عشوائي طويل.

3) **إنشاء قاعدة البيانات والجداول والبيانات الأساسية:**

       npm run db:create
       npm run migrate
       npm run seed

   يُنشئ الـ seed حساب المعلمة الأول:
   - اسم المستخدم: `admin`
   - كلمة المرور: `lughati1234`

   **غيّري كلمة المرور فوراً من «الإعدادات» بعد أول دخول.**

4) **تشغيل الخادم** (نافذة أوامر):

       npm run dev:server

   تأكدي من: http://localhost:4000/api/health → `{"status":"ok","db":"ok",...}`

5) **تشغيل الواجهة** (نافذة أوامر ثانية):

       npm run dev:web

   ثم افتحي http://localhost:5173

## إدخال الطالبات
من شاشة «الطالبات» ← «استيراد سريع»: سطر لكل طالبة بالصيغة:

    الاسم، الصف، الشعبة

(الصف والشعبة اختياريان — الافتراضي: الرابع / أ). تُتجاهل المكررات تلقائياً.
كذلك يمكن الاستيراد من `database/students.csv` بنفس الصيغة. لا توجد أسماء جاهزة في القاعدة — الإدخال منك فقط.

## الاختبارات الآلية (27 اختباراً ضد PostgreSQL حقيقي)

    npm run db:create -- test
    npm test

تغطي: تسجيل الدخول والجلسات، فرض الصلاحيات في الخادم، خصوصية ملفات الطالبات،
التقييم التراكمي (تقييمان بنفس اليوم)، منع درجات الغائبات، حساب الأسبوع (يبدأ الأحد)،
وإبطال الجلسة عند تغيير كلمة المرور.

## التشغيل الإنتاجي

    npm run build      # يبني الواجهة داخل frontend/dist
    npm start          # يقدم الواجهة والـ API معاً من نفس المنفذ

ملاحظات:
- في `.env` ضعي `NODE_ENV=production` و`JWT_SECRET` قوياً و`CORS_ORIGIN` بنطاقك.
- في الإنتاج تُرسل كوكي الجلسة بعلامة `Secure` — تحتاجين HTTPS (عبر IIS أو Nginx كوكيل عكسي).
- النسخ الاحتياطي الدوري: `pg_dump -U postgres lughati > backup.sql`
- لا ترفعي `.env` ولا مجلد `uploads/` إلى أي مكان عام.

## بنية المشروع

    lughati/
    ├── database/          migrations + seeds + students.csv
    ├── backend/           خادم Express + TypeScript
    │   └── src/           config, db (pool), middleware, services, controllers, routes, scripts
    ├── frontend/          واجهة React + Vite + TypeScript
    │   └── src/           api, auth, components, pages(teacher|student), styles
    ├── tests/             اختبارات API (vitest + supertest)
    └── uploads/           الملفات المرفوعة (خارج git)

## وثائق الـ API (كلها تحت /api)

| المسار | الطريقة | الصلاحية |
|---|---|---|
| /auth/login | POST | عام (قفل مؤقت بعد 5 محاولات فاشلة) |
| /auth/logout | POST | مصادق |
| /auth/me | GET | مصادق |
| /auth/change-password | POST | مصادق (يبطل الجلسات القديمة) |
| /users | GET / POST / PATCH | معلمة/إدارة (الفرض داخل الخادم) |
| /users/:id | DELETE | إدارة فقط |
| /students | GET | معلمة/إدارة (+طالبة لنفسها) |
| /students , /students/import | POST | معلمة |
| /students/:id | PATCH / DELETE | معلمة (الرمز code غير قابل للتعديل) |
| /evaluations | GET | معلمة/إدارة (+طالبة لبياناتها فقط — وإلا 403) |
| /evaluations | POST، DELETE /:id | معلمة (تراكمي — لا يستبدل سابقاً) |
| /worksheets | GET | معلمة/إدارة (+طالبة لأوراق صفها) |
| /worksheets | POST (مرفق اختياري)، PATCH /:id/status، DELETE /:id | معلمة |
| /tests | GET / POST / DELETE /:id | GET متاح للطالبة (نتائجها فقط) |
| /tests/:id/results | PUT | معلمة (رصد جماعي، تحقق 0..الحد) |
| /plans | GET / POST / PATCH /:id | GET متاح للطالبة (خططها) |
| /plans/:id/followups | POST | معلمة |
| /skills | GET / POST | GET متاح للطالبة (مستوياتها) |
| /skills/:id/levels | PUT | معلمة |
| /messages/threads | GET | معلمة/إدارة |
| /messages/:studentId | GET | معلمة/إدارة + الطالبة (نفسها فقط) |
| /messages | POST | معلمة + طالبة (بنفسها فقط، ≤4000 حرف) |
| /star/current , /star | GET | مصادق |
| /star | PUT | معلمة (الأسبوع يبدأ الأحد) |
| /achievements | GET / POST / PATCH /:id / DELETE /:id | GET متاح للطالبة (المرئي فقط) |
| /files/:id | GET | مصادق (فحص ملكية بالخادم — 404 لغير المصرح) |
| /reports/summary , /reports/compare | GET | معلمة/إدارة |
| /reports/student/:id | GET | معلمة/إدارة + الطالبة (نفسها) |
| /settings | GET (مصادق) | PUT + POST /logo (معلمة) |
| /audit | GET | إدارة فقط |
| /health | GET | عام |

## أمان مدمج
- كلمات المرور مجزأة bcrypt داخل الخادم فقط — لا شيء حساس في كود الواجهة.
- الجلسة JWT داخل كوكي httpOnly (8 ساعات) + `token_version` لإبطال فوري عند تغيير كلمة المرور.
- دور كل مستخدم يُقرأ من قاعدة البيانات مع **كل طلب** — الصلاحيات ليست إخفاء واجهة.
- الطالبة ترى بياناتها فقط؛ ملفاتها لا تُفتح بتغيير الرابط (404 دون كشف).
- سجل تدقيق (audit_logs) للعمليات الحساسة يعرضه دور «الإدارة».
- التقييم تراكمي؛ لا درجات لأي طالبة غير حاضرة (قيد في القاعدة + فحص بالخادم).

## الضغط إلى ZIP
كليك يمين على مجلد `lughati` ← «ضغط إلى ملف ZIP».
للتصغير قبل الضغط: احذفي `node_modules` و`dist` (يُعاد بناؤهما بـ `npm install` و`npm run build`)،
ولا تضمّني `.env` عند المشاركة مع أي جهة خارجية.
